# wdd331r_week4assignment
This is our Style Guide for week 4's assignment. The html for our theme are shown as well but not a lot at this time.
